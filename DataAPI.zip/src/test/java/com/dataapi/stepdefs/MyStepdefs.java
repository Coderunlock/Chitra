package com.dataapi.stepdefs;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.dataapi.runners.WebDriverFactory;
import com.dataapi.server.HealthCheck;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.openqa.selenium.By;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

public class MyStepdefs {
        HealthCheck checks = new HealthCheck(WebDriverFactory.getDriver());;
        @Then("^Navigate to DataAPI Health Checks URL for : \"([^\"]*)\"$")
        public void userLaunchDataAPIHealthUrls(String server) throws Exception {
                String url= "http://"+server.trim()+":8451/DataAPIHealthCheck.aspx";
                WebDriverFactory.getDriver().manage().window().maximize();
                WebDriverFactory.getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
                WebDriverFactory.getDriver().get(url);
                ExtentCucumberAdapter.addTestStepLog("Health check for Server : "+url+" is :");
                checks.verifyDataAPIHealth(url);
        }

        @Then("^Navigate to DataAPI Health Checks URL for TS : \"([^\"]*)\"$")
        public void userLaunchDataAPIHealthUrlsTS(String server) throws Exception {
                String url= "http://"+server.trim()+":8451/DataAPIHealthCheck.aspx";
                WebDriverFactory.getDriver().manage().window().maximize();
                WebDriverFactory.getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
                WebDriverFactory.getDriver().get(url);
                ExtentCucumberAdapter.addTestStepLog("Health check for Server : "+url+" is :");
                checks.verifyDataAPIHealth(url);
        }

        @Then("^Navigate to DataAPI Health Checks URL for Cloud : \"([^\"]*)\"$")
        public void userLaunchDataAPIHealthUrlsCloud(String server) throws Exception {
                String url= "http://"+server.trim()+".ciqtest.spglobal.com:8451/DataAPIHealthcheck.aspx";
                WebDriverFactory.getDriver().manage().window().maximize();
                WebDriverFactory.getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
                WebDriverFactory.getDriver().get(url);
                ExtentCucumberAdapter.addTestStepLog("Health check for Server : "+url+" is :");
                checks.verifyDataAPIHealth(url);
        }

        @Then("^Navigate to DataAPI Health Checks URL for DR Cloud : \"([^\"]*)\"$")
        public void userLaunchDataAPIHealthUrlsDRCloud(String server) throws Exception {
                String url= "http://"+server.trim()+":8451/DataAPIHealthcheck.aspx";
                WebDriverFactory.getDriver().manage().window().maximize();
                WebDriverFactory.getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
                WebDriverFactory.getDriver().get(url);
                ExtentCucumberAdapter.addTestStepLog("Health check for Server : "+url+" is :");
                checks.verifyDataAPIHealth(url);
        }

}
