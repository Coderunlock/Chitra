package com.dataapi.stepdefs;

import com.dataapi.runners.WebDriverFactory;
import com.dataapi.utils.ConfigReader;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class Hooks {
    ConfigReader configReader;
    Properties properties;
    WebDriverFactory driverFactory;
    WebDriver driver;

    @Before(order = 0)
    public void getPropertyValues() {
        configReader = new ConfigReader();
        properties = configReader.intializeProperties();
    }

    @Before(order = 1)
    public void setup(Scenario scenario) {
        //Set DriverManager
        String browserName = configReader.getBrowserName();
        driverFactory = new WebDriverFactory();
        driver = driverFactory.setupDriver(browserName);
        driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
    }

    @After
    public void tearDown(Scenario sceanrio) {
        //Close the driver
        String scenarioName = sceanrio.getName();
        if (sceanrio.isFailed()) {
            TakesScreenshot takescreenshot = (TakesScreenshot) driver;
            byte[] screnshot = takescreenshot.getScreenshotAs(OutputType.BYTES);
            sceanrio.attach(screnshot, "image/png", scenarioName);
        }
        driver.quit();
    }
}
