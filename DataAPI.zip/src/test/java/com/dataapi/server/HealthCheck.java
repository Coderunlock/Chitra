package com.dataapi.server;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class HealthCheck {

    WebDriver driver;

    public HealthCheck(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver,this);
    }

    public void verifyDataAPIHealth(String server) throws Exception {
        for(int i =1; i<=16; i=i+1) {
            String text=driver.findElement(By.xpath("//div[contains(@class,'ui-accordion ui-widget')]//h3["+i+"]")).getText().trim();
            if(text.contains("OK")) {
                ExtentCucumberAdapter.addTestStepLog("Health check for "+text);
            }
            else {
                ExtentCucumberAdapter.addTestStepLog("Health check for <b><i><u><p style=\"color:red;\">"+ text +"</p></u></i></b>");
            }
        }
    }
}
