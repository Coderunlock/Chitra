package com.dataapi.runners;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.Objects;

public class WebDriverFactory {
    public WebDriver driver;
    public static ThreadLocal<WebDriver> webdriver = new ThreadLocal<>();
    public WebDriver setupDriver(String browser) {
        if(browser.equalsIgnoreCase("firefox")) {
            WebDriverManager.firefoxdriver().setup();
            webdriver.set(new FirefoxDriver());
        }
        else {
            WebDriverManager.chromedriver().setup();
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--remote-allow-origins=*");
            webdriver.set(new ChromeDriver(options));
        }
        return getDriver();
    }

    public static WebDriver getDriver() {
        return webdriver.get();
    }
}
